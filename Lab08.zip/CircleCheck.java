/*
 * Created on: Mar 22, 2023
 *
 * ULID: cqtroja
 * Class: IT 168 
 */
package edu.ilstu;

import java.util.Scanner;

/**
 * <insert class description here>
 *
 * @author Cameron Trojan
 *
 */
public class CircleCheck
{

	/**
	 * @param args
	 */
	public static void main(String[] args)
	{
		Scanner sc = new Scanner(System.in);

		System.out.println("Enter radius of a circle: ");
		double rad = sc.nextDouble();

		Circle c = new Circle(rad);
		System.out.println("Radius = " + c.getRadius());
		System.out.println("Area = " + c.calculateArea());
		System.out.println("Diameter = " + c.calculateDiameter());
		System.out.println("Circumference = " + c.calculateCircumference());

	}

}
