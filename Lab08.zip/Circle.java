/*
 * Created on: Mar 22, 2023
 *
 * ULID: cqtroja
 * Class: IT 168 
 */
package edu.ilstu;

/**
 * Asks user for radius of a circle and returns the ciricles area, diameter, and
 * circumference
 *
 * @author Cameron Trojan
 *
 */

public class Circle
{

	private double radius;
	final double PI = 3.14159;

	/**
	 * 
	 * @param radius - radius of the circle
	 */
	public Circle(double radius)
	{
		this.radius = radius;
	}

	/**
	 * 
	 * @return radius
	 */
	public double getRadius()
	{
		return radius;
	}

	/**
	 * 
	 * @param radius
	 */
	public void setRadius(double radius)
	{
		this.radius = radius;
	}

	/**
	 * 
	 * @return area
	 */
	public double calculateArea()
	{
		return PI * radius * radius;
	}

	/**
	 * 
	 * @return diameter
	 */
	public double calculateDiameter()
	{
		return radius * 2;
	}

	/**
	 * 
	 * @return circumference
	 */
	public double calculateCircumference()
	{
		return 2 * PI * radius;
	}
}
