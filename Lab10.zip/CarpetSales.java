/*
 * Created on: Apr 4, 2023
 *
 * ULID: cqtroja
 * Class: IT 168 
 */
package edu.ilstu;

/**
 * <insert class description here>
 *
 * @author Cameron Trojan
 *
 */
public class CarpetSales
{

	/**
	 * @param args
	 */
	public static void main(String[] args)
	{
		RoomDimension roomDimension = new RoomDimension(12, 10);
		RoomCarpet roomCarpet = new RoomCarpet(roomDimension, 8);
		System.out.println("Total cost: $" + roomCarpet.getTotalCost());
	}

}
