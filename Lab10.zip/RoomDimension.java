/*
 * Created on: Apr 4, 2023
 *
 * ULID: cqtroja
 * Class: IT 168 
 */
package edu.ilstu;

/**
 * <insert class description here>
 *
 * @author Cameron Trojan
 *
 */
public class RoomDimension
{
	private double length;
	private double width;

	public RoomDimension(double length, double width)
	{
		this.length = length;
		this.width = width;
	}

	public double getLength()
	{
		return length;
	}

	public double getWidth()
	{
		return width;
	}

	public double getArea()
	{
		return length * width;
	}

	@Override
	public String toString()
	{
		return "Room Dimension [length=" + length + ", width=" + width + "]";
	}
}