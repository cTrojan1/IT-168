/*
 * Created on: Apr 4, 2023
 *
 * ULID: cqtroja
 * Class: IT 168 
 */
package edu.ilstu;

/**
 * <insert class description here>
 *
 * @author Cameron Trojan
 *
 */
public class RoomCarpet
{
	private RoomDimension roomDimension;
	private double costPerSquareFoot;

	public RoomCarpet(RoomDimension roomDimension, double costPerSquareFoot)
	{
		this.roomDimension = roomDimension;
		this.costPerSquareFoot = costPerSquareFoot;
	}

	public double getTotalCost()
	{
		return roomDimension.getArea() * costPerSquareFoot;
	}

	@Override
	public String toString()
	{
		return "Room Carpet [roomDimension=" + roomDimension.toString() + ", costPerSquareFoot=" + costPerSquareFoot
				+ "]";
	}
}
