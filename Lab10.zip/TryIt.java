/*
 * Created on: Apr 4, 2023
 *
 * ULID: cqtroja
 * Class: IT 168 
 */
package edu.ilstu;

/**
 * Q1: When determining if two strings are the same, the .equals method is
 * preferred
 * 
 * Q2: Yes, the value will be changed in the calling method
 * 
 * Q3: No, if you pass a primitive variable to a method and change its value
 * inside the method, the value is not changed back in the calling method
 *
 * @author Cameron Trojan
 *
 */
public class TryIt
{

	/**
	 * @param args
	 */
	public static void main(String[] args)
	{
		String s1 = "Testing";
		String s2 = "Testing";
		String s3 = "String testing";

		System.out.println(s1.equals(s3));// false
		System.out.println(s1.equals(s2));// true
		System.out.println(s1 == s2);// true
		System.out.println(s1 == s3);// false

		String S1 = new String("Case2");
		String S2 = new String("Case2");
		String S3 = new String("Case3");

		System.out.println("");
		System.out.println(S1.equals(S3));// false
		System.out.println(S1.equals(S2));// true
		System.out.println(S1 == S2);// true
		System.out.println(S1 == S3);// false

		testTempVars();

		int originalInt = 10;
		System.out.println("Original value of int variable: " + originalInt);

		primitivePassing(originalInt);

		System.out.println("Value of original int variable after primitivePassing executes: " + originalInt);
	}

	public static void testTempVars()
	{
		BankAccount myAccount = new BankAccount(500.0, "Mike Jones", "555555");
		System.out.println("Original value of bank account: ");
		System.out.println(myAccount.toString());

		objectPassing(myAccount);

		System.out.println("Value of bank account after objectPassing executes: ");
		System.out.println(myAccount.toString());
	}

	public static void objectPassing(BankAccount acct)
	{
		acct.deposit(200.0);
		System.out.println("Value of bank account in objectPassing: ");
		System.out.println(acct.toString());
	}

	public static void primitivePassing(int num)
	{
		num = num - 5;
		System.out.println("primitivePassing value: " + num);
	}
}
