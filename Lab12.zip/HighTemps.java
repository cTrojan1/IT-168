/*
 * Created on: Apr 21, 2023
 *
 * ULID: cqtroja
 * Class: IT 168 
 */
package edu.ilstu;

/**
 * <insert class description here>
 *
 * @author Cameron Trojan
 *
 */
import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class HighTemps
{

	public static void main(String[] args)
	{
		int[] temperatureArray = new int[151]; // Array to store number of days for each temperature
		int temperature;

		for (int i = 0; i < 151; i++)
		{
			// Initialize the array with 0 for each temperature
			temperatureArray[i] = 0;
		}

		Scanner input = null;
		try
		{
			input = new Scanner(new File("temps.txt"));
			while (input.hasNextInt())
			{
				temperature = input.nextInt();
				// Check for valid temperature
				if (temperature < -40 || temperature > 110)
				{
					System.out.printf("Invalid temperature: %d%n", temperature);
					continue;
				}
				temperatureArray[temperature + 40]++;
			}
		} catch (FileNotFoundException e)
		{
			System.out.println("File not found: temps.txt");
			System.exit(1);
		} finally
		{
			if (input != null)
			{
				input.close();
			}
		}

		System.out.println("Temperature  |  Number of Days");
		for (int i = -40; i <= 110; i++)
		{
			// Print the temperature and number of days for each temperature
			if (temperatureArray[i + 40] > 0)
			{
				System.out.printf("%d°F       |       %d%n", i, temperatureArray[i + 40]);
			}
		}
	}

}
