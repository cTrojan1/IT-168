package edu.ilstu;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

/**
 * <insert class description here>
 * 
 * @author Mary Elaine Califf and Cameron Trojan
 *
 */
public class ArrayManager
{
	// declare instance variables here
	private int[] array;
	private int count;

	public ArrayManager()
	{
		array = new int[100];
		count = 0;
	}

	public void fillArray()
	{
		int curVal;
		Scanner input = null;
		try
		{
			input = new Scanner(new File("data.txt"));
			count = 0;

			while (input.hasNextInt() && count < 100)
			{
				curVal = input.nextInt();
				array[count] = curVal;
				count++;
			}
			input.close();
		} catch (FileNotFoundException e)
		{
			System.out.println("Could not find data.txt file");
			System.exit(1);
		}
	}

	public int getSmallest()
	{
		int smallest = array[0];
		for (int i = 1; i < count; i++)
		{
			if (array[i] < smallest)
			{
				smallest = array[i];
			}
		}
		return smallest;
	}

	public int getLargest()
	{
		int largest = array[0];
		for (int i = 1; i < count; i++)
		{
			if (array[i] > largest)
			{
				largest = array[i];
			}
		}
		return largest;
	}

	public int findFirstInstance(int value)
	{
		for (int i = 0; i < count; i++)
		{
			if (array[i] == value)
			{
				return i;
			}
		}
		return -1;
	}
}