/*
 * Created on: Apr 19, 2023
 *
 * ULID: cqtroja
 * Class: IT 168 
 */
package edu.ilstu;

import java.util.Scanner;

/**
 * <insert class description here>
 *
 * @author Cameron Trojan
 *
 */
public class moreArrayFun
{

	/**
	 * @param args
	 */
	public static void main(String[] args)
	{
//		When you submit your program, your main must do the following:
//			1) Create an ArrayManager object using the default constructor
//			2) Call fillArray with that object
//			3) Print out the smallest value in the array with an appropriate label (having
//			used the appropriate method to determine that value)
//			4) Print out the largest value in the array with an appropriate label (having
//			used the appropriate method to determine that value)
//			5) Use a sentinel-controlled loop to ask the user for values and use the
//			appropriate method to look up each value, printing the index with a label if
//			found and “Not found” otherwise. Use a sentinel value of -999. Do not search
//			for the sentinel value.
		Scanner sc = new Scanner(System.in);
		int input = 0;

		ArrayManager arrayManager = new ArrayManager();

		arrayManager.fillArray();

		System.out.println(arrayManager.getSmallest());
		System.out.println(arrayManager.getLargest());

		while (input != -999)
		{
			System.out.println("Enter a value or -999 to stop: ");
			input = sc.nextInt();
			if (input == -999)
			{
				break;
			} else
			{
				int index = arrayManager.findFirstInstance(input);
				if (index == -1)
				{
					System.out.println("Value " + input + " not found");
				} else
				{
					System.out.println("First instance of value " + input + ": " + index);
				}
			}
		}
	}

}
