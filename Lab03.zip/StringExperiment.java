/*
 * Created on: Feb 1, 2023
 *
 * ULID: cqtroja
 * Class: IT 168 
 */
package edu.ilstu;

/**
 * <insert class description here>
 *
 * @author Cameron Trojan
 *
 */
public class StringExperiment
{

	public static void main(String[] args)
	{
		String first = ("Cameron");
		String middle = ("Quinn");
		String last = ("Trojan");

		System.out.println(first + " " + middle + " " + last);

		System.out.println(first + " " + middle.charAt(0) + ". " + last);

		System.out.println(first.toUpperCase() + " " + last);

		System.out.println("Length of last name: " + last.length());

		System.out.println(middle.charAt(2));

		System.out.println(first.charAt(6));
	}

}
