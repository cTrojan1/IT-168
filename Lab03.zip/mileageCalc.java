package edu.ilstu;

import java.util.Scanner;
/*
 * Created on: Feb 1, 2023
 *
 * ULID: cqtroja
 * Class: IT 168 
 */

/**
 * <insert class description here>
 *
 * @author Cameron Trojan
 *
 */
public class mileageCalc
{

	public static void main(String[] args)
	{
		Scanner sc = new Scanner(System.in);
		System.out.println("How many gallons were used: ");
		int gal = sc.nextInt();

		System.out.println("How many miles were driven: ");
		int miles = sc.nextInt();

		int mpg = miles / gal;

		System.out.println("MPG: " + mpg);

	}

}
