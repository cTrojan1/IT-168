/*
 * Created on: Mar 25, 2023
 *
 * ULID: cqtroja
 * Class: IT 168 
 */
package edu.ilstu;

/**
 * Constructor for the TimeTester class which will take a time input and prints
 * specifics such as "AM" or "PM", and returns time as military or 12 hour
 *
 * @author Cameron Trojan and Illexia Williams
 *
 */
public class Time
{
	private int hours;
	private int minutes;

	public Time()
	{
		this.hours = 0;
		this.minutes = 0;
	}

	// Checks to see if variables are in bounds of constructor
	/**
	 * Constructor for 24 hour time
	 * 
	 * @param hours
	 * @param minutes
	 */
	public Time(int hours, int minutes)
	{
		if (hours >= 0 && hours <= 23 && minutes >= 0 && minutes <= 59)
		{
			this.hours = hours;
			this.minutes = minutes;
		} else
		{
			this.hours = 0;
			this.minutes = 0;
		}

	}

	// Checks if variables are in bounds of constructor and checks for period input
	/**
	 * Constructor for 12 hours time
	 * 
	 * @param hours   - Time in hours
	 * @param minutes - Time in minutes
	 * @param period  - AM or PM
	 */
	public Time(int hours, int minutes, String period)
	{
		if ((hours >= 1 && hours <= 12) && (minutes >= 0 && minutes <= 59)
				&& (period.equalsIgnoreCase("AM") || period.equalsIgnoreCase("PM")))
		{
			if (period.equalsIgnoreCase("PM") && hours != 12)
			{
				hours += 12;
			}

			else if (period.equalsIgnoreCase("AM") && hours == 12)
			{
				hours = 0;
			}
			this.hours = hours;
			this.minutes = minutes;
		} else
		{
			this.hours = 0;
			this.minutes = 0;
		}
	}

	/**
	 * Getter for hours
	 * 
	 * @return Hours
	 */
	public int getHours()
	{
		return hours;
	}

	/**
	 * Setter for current hour
	 * 
	 * @param hours Current hours
	 */
	public void setHours(int hours)
	{
		if (hours >= 0 && hours <= 23)
		{
			this.hours = hours;
		}
	}

	/**
	 * Getter for minutes
	 * 
	 * @return Minutes
	 */
	public int getMinutes()
	{
		return minutes;
	}

	/**
	 * Setter for minutes
	 * 
	 * @param minutes
	 */
	public void setMinutes(int minutes)
	{
		if (minutes >= 0 && minutes <= 59)
		{
			this.minutes = minutes;
		}
	}

	public boolean equals(Object obj)
	{
		if (obj == null || !(obj instanceof Time))
		{
			return false;
		}
		Time other = (Time) obj;
		return (this.hours == other.getHours() && this.minutes == other.getMinutes());
	}

	public String toString()
	{
		return String.format("%02d:%02d", this.hours, this.minutes);
	}

	/**
	 * Getter for 12 hour time constructor
	 * 
	 * @return Returns 12 hour time
	 */
	public String get12HourTime()
	{
		int hours12 = this.hours % 12;
		if (hours12 == 0)
		{
			hours12 = 12;
		}
		String period = (this.hours >= 12) ? "PM" : "AM";
		return String.format("%02d:%02d %s", hours12, this.minutes, period);
	}
}
