/*
 * Created on: Mar 25, 2023
 *
 * ULID: cqtroja
 * Class: IT 168 
 */
package edu.ilstu;

/**
 * This class runs the class Time
 *
 * @author Cameron Trojan
 *
 */
public class TimeTester
{
	public static void main(String[] args)
	{
		Time t0 = new Time(13, 30);// prints "t0: 1:30 PM"
		System.out.println("t0: " + t0.get12HourTime());
		// Create a Time object using the default constructor
		Time t1 = new Time();
		System.out.println("t1: " + t1.toString()); // prints "t1: 00:00"

		// Create a Time object using the constructor that takes hours and minutes
		Time t2 = new Time(11, 30);
		System.out.println("t2: " + t2.toString()); // prints "t2: 11:30"

		// Create a Time object using the constructor that takes hours, minutes, and
		// period
		Time t3 = new Time(7, 45, "PM");
		System.out.println("t3: " + t3.get12HourTime()); // prints "t3: 07:45 PM"

		// Changes the time of t2 to 2:15 using setters
		t2.setHours(2);
		t2.setMinutes(15);
		System.out.println("t2: " + t2.toString()); // prints "t2: 02:15"

		// Compares t2 and t3 using the equals method
		if (t2.equals(t3))
		{
			System.out.println("t2 and t3 are equal");
		} else
		{
			System.out.println("t2 and t3 are not equal");
		}

		t2.setHours(19);
		t2.setMinutes(45);

		System.out.println(t2);

		if (t2.equals(t3))
		{
			System.out.println("t2 and t3 are equal");
		} else
		{
			System.out.println("t2 and t3 are not equal");
		}
	}
}