/*
 * Created on: Apr 12, 2023
 *
 * ULID: cqtroja
 * Class: IT 168 
 */
package edu.ilstu;

import java.util.Scanner;

/**
 * This class creates 3 methods that perform various array operations such as
 * calculating the product, printing the array to the screen, filling the array
 * with user inputs, and counts the multiples of a user defined value in the
 * array.
 *
 * @author Cameron Trojan
 *
 */
public class ArrayFun
{
	Scanner sc = new Scanner(System.in);

	/**
	 * @param args
	 */
	public static void main(String[] args)
	{
		Scanner sc = new Scanner(System.in);
		int[] arr = new int[100];
		int arrInt = 0;

		fillArray(arr);

		for (int i = 0; i < arr.length; i++)
		{
			if (arr[i] != 0)
			{
				arrInt++;
			}
		}

		computeProduct(arr, arrInt);

		System.out.println("Enter a factor: ");
		int factor = sc.nextInt();

		countMultiples(arr, arrInt, factor);

		printArray(arr, arrInt);

		System.out.println("\nThere are " + arrInt + " valid values in this array.");

	}

	/**
	 * This method takes an array and fills it with user inputs
	 * 
	 * @param array Array of numbers
	 * @return returns index of array
	 */
	public static int fillArray(int[] array)
	{
		Scanner sc = new Scanner(System.in);

		int sent = -999;
		int index = 0;
		int user;

		System.out.println("Enter a number or -999 to stop: ");
		user = sc.nextInt();

		while (user != sent && index < 100)
		{
			array[index] = user;
			index++;
			user = sc.nextInt();
		}
		return index;

	}

	/**
	 * This method takes an array, and two integers count and factor that will count
	 * the multiples of the given factor
	 * 
	 * @param array  Array of numbers
	 * @param count  Number of valid values in the array
	 * @param factor Factor to be used
	 * @return Returns the number of multiples in the array
	 */
	public static int countMultiples(int[] array, int count, int factor)
	{
		int multiplesCount = 0;

		for (int i = 0; i < count; i++)
		{
			if (array[i] % 2 == 0)
			{
				multiplesCount++;
			}
		}
		System.out.println("There are " + multiplesCount + " multiples of " + factor);
		return multiplesCount;

	}

	/**
	 * This method calculates the product of a given array
	 * 
	 * @param array  Array of numbers
	 * @param values Number of valid values in the array
	 * @return Returns the product of the array
	 */
	public static int computeProduct(int[] array, int values)
	{
		int i = 1;
		int product = 1;

		while (i < values)
		{
			product = product * array[i];
			i++;

		}
		System.out.println("The product of the array is: " + product);
		return product;
	}

	/**
	 * This method prints all valid values in an array
	 * 
	 * @param array  Array of numbers
	 * @param values Number of valid values in an array
	 */
	public static void printArray(int[] array, int values)
	{
		for (int i = 0; i < values; i++)
		{

			System.out.print(array[i] + ", ");
		}
	}
}
