/*
 * Created on: Feb 21, 2023
 *
 * ULID: cqtroja
 * Class: IT 168 
 */
package edu.ilstu;

/**
 * This class takes an input up to 100 cents from the user and displays
 * their change in quarters, dimes, and nickels depending on their purchase
 *
 * @author Cameron Trojan
 *
 */
import java.util.Scanner;

public class ChangeMaker
{
	public static void main(String[] args)
	{
		Scanner sc = new Scanner(System.in);

		int min = 25;
		int max = 100;
		int user = 0;
		int quarters = 0;
		int dimes = 0;
		int nickels = 0;
		int remain = 0;

		System.out.println("Item price must be 25 cents to a dollar, in 5-cent increments.");
		System.out.print("Enter item price: ");
		user = sc.nextInt();

		remain = 100 - user;

		quarters = remain / 25;
		remain = remain % 25;

		dimes = remain / 10;
		remain = remain % 10;

		nickels = remain / 5;
		remain = remain % 5;

		if (user < min)
		{
			System.out.println("Cost is invalid - it must be at least 25 cents.");
			System.exit(0);
		}

		if (user > max)
		{
			System.out.println("Cost is invalid - it must be no more than 100 cents.");
			System.exit(0);
		}

		if (user % 5 != 0)
		{
			System.out.println("Cost is invalid - it must be evenly divisible by 5");
			System.exit(0);
		}

		System.out.println("You bought an item for " + user + " cents and gave me a dollar.");
		System.out.println("Your change is: ");

		if (quarters == 1)
			System.out.println(quarters + " quarter");
		if (quarters > 1)
			System.out.println(quarters + " quarters");
		if (dimes == 1)
			System.out.println(dimes + " dime");
		if (dimes > 1)
			System.out.println(dimes + " dimes");
		if (nickels == 1)
			System.out.println(nickels + " nickel");
		if (nickels > 1)
			System.out.println(nickels + " nickels");

	}

}
