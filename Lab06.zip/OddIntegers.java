/*
 * Created on: Feb 22, 2023
 *
 * ULID: cqtroja
 * Class: IT 168 
 */
package edu.ilstu;

/**
 * This prgram asks the user for an input, takes that input and adds 
 * together odd numbers starting from 1 until the user input number has been reached 
 * in numbers printed 
 * 
 *
 * @author Cameron Trojan
 *
 */
import java.util.Scanner;

public class OddIntegers
{

	int counter = 0;
	static int num = 1;
	static int sum = 0;
	static Scanner sc = new Scanner(System.in);

	public static void main(String[] args)
	{

		System.out.println("How many positive odd integers do you want to add? ");
		int counter = sc.nextInt();

		while (counter != 1)
		{
			System.out.print(num + " + ");

			sum = sum += num;
			num += 2;
			counter--;

		}
		System.out.print(num += 2);

		sum += num;

		System.out.print(" = " + sum);
	}
}
