/*
 * Created on: Feb 25, 2023
 *
 * ULID: cqtroja
 * Class: IT 168 
 */
package edu.ilstu;

/**
 * <insert class description here>
 *
 * @author Cameron Trojan
 *
 */
import java.util.Scanner;

public class ExamCalculations
{
	public static void main(String[] args)
	{
		Scanner sc = new Scanner(System.in);

		int count = 0;
		int sum = 0;
		int minScore = 100;
		int maxScore = 0;
		int numAs = 0;
		double averageScore = 0;

		while (true)
		{
			System.out.print("Enter a score (or -1 to end): ");
			int score = sc.nextInt();

			if (score == -1)
			{
				break;
			}

			if (score > maxScore)
			{
				maxScore = score;
			}

			if (score < minScore)
			{
				minScore = score;
			}

			if (score >= 90 && score <= 100)
			{
				numAs++;
			}

			count++;
			sum += score;
		}

		if (count == 0)
		{
			System.out.println("No scores entered.");
		} else
		{
			averageScore = sum / count;
			System.out.println("Number of students: " + count);
			System.out.println("Minimum score: " + minScore);
			System.out.println("Maximum score: " + maxScore);
			System.out.println("Average score: " + averageScore);
			System.out.println("Number of A's: " + numAs);
		}
	}
}
