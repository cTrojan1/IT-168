/*
 * Created on: Mar 8, 2023
 *
 * ULID: cqtroja
 * Class: IT 168 
 */
package edu.ilstu;

import java.util.Scanner;

/**
 * <insert class description here>
 *
 * @author Cameron Trojan
 *
 */
public class PrintTriangle
{

	public static void main(String[] args)
	{
		Scanner sc = new Scanner(System.in);

		int user = 0;

		System.out.println("Enter a number between 3-40: ");
		user = sc.nextInt();

		if (user < 3 || user > 40)
		{
			System.out.println("Invalid input. Please enter an integer between 3 and 40.");
			return;
		}

		for (int i = 1; i <= user; i++)
		{
			for (int j = 1; j <= i; j++)
			{
				System.out.print("*");
			}
			System.out.println();
		}
	}
}
