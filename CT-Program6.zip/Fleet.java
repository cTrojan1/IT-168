/*
 * Created on: Apr 24, 2023
 *
 * ULID: cqtroja
 * Class: IT 168 
 */
package edu.ilstu;

/**
 * <insert class description here>
 *
 * @author Cameron Trojan
 *
 */
import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.time.LocalDate;
import java.util.Arrays;
import java.util.Comparator;
import java.util.Scanner;

public class Fleet
{

	private Aircraft[] aircrafts;
	private int count;

	public Fleet()
	{
		this.aircrafts = new Aircraft[100];
		this.count = 0;
	}

	public void readFile(String filename)
	{
		try
		{
			Scanner scanner = new Scanner(new File(filename));
			while (scanner.hasNextLine())
			{
				String aircraftName = scanner.nextLine();
				String regNumber = scanner.nextLine();
				String manufacturer = scanner.nextLine();
				int maxRange = scanner.nextInt();
				int crewSize = scanner.nextInt();
				int yearPutInService = scanner.nextInt();
				int maxServiceWeight = scanner.nextInt();
				int numPassengers = scanner.nextInt();
				LocalDate lastMaintenanceDate = LocalDate.now();
				int lastMaintenanceMiles = scanner.nextInt();

				Aircraft aircraft = new Aircraft(aircraftName, regNumber, manufacturer, maxRange, crewSize,
						yearPutInService, maxServiceWeight, numPassengers, lastMaintenanceDate, lastMaintenanceMiles);

				addAircraft(aircraft);
			}
			scanner.close();
		} catch (FileNotFoundException e)
		{
			System.out.println("File not found: " + filename);
		} catch (NumberFormatException e)
		{
			System.out.println("Invalid format in file: " + filename);
		} catch (Exception e)
		{
			System.out.println("An error occurred while reading the file: " + filename);
		}
	}

	public void writeFile(String filename)
	{
		try
		{
			sortArray();
			PrintWriter writer = new PrintWriter(new File(filename));
			for (int i = 0; i < count; i++)
			{
				Aircraft aircraft = aircrafts[i];
				writer.println(aircraft.getAircraftName());
				writer.println(aircraft.getRegNumber());
				writer.println(aircraft.getManufacturer());
				writer.println(aircraft.getMaxRange());
				writer.println(aircraft.getCrewSize());
				writer.println(aircraft.getYearPutInService());
				writer.println(aircraft.getMaxServiceWeight());
				writer.println(aircraft.getNumPassengers());
				writer.println(aircraft.getLastMaintenanceDate());
				writer.println(aircraft.getLastMaintenanceMiles());
			}
			writer.close();
		} catch (Exception e)
		{
			System.out.println("An error occurred while writing to file: " + filename);
		}
	}

	public void sortArray()
	{
		Arrays.sort(aircrafts, 0, count, new Comparator<Aircraft>()
		{
			public int compare(Aircraft a1, Aircraft a2)
			{
				return a1.getRegNumber().compareTo(a2.getRegNumber());
			}
		});
	}

	public void addAircraft(Aircraft aircraft)
	{
		for (int i = 0; i < count; i++)
		{
			if (aircrafts[i].getRegNumber().equals(aircraft.getRegNumber()))
			{
				System.out.println(
						"Error: Aircraft with registration number " + aircraft.getRegNumber() + " already exists");
				return;
			}
		}
		aircrafts[count] = aircraft;
		count++;
	}

	public void displayFleet()
	{
		for (int i = 0; i < count; i++)
		{
			System.out.println(aircrafts[i].toString());
		}
	}

	public void displayMaintenanceList()
	{
		LocalDate currentDate = LocalDate.now();
		for (int i = 0; i < count; i++)
		{
			Aircraft aircraft = aircrafts[i];
			if (aircraft.needsMaintenance(currentDate))
			{
				System.out.println(aircraft.toString());
			}
		}
	}

	public void displayNextMaintenanceList()
	{
		LocalDate currentDate = LocalDate.now();
		System.out.println("Name\tManufacturer\tNext Maintenance Date\tNext Maintenance Miles");
		for (int i = 0; i < count; i++)
		{
			Aircraft aircraft = aircrafts[i];
			LocalDate nextMaintenanceDate = aircraft.getNextMaintenanceDate(currentDate);
			long nextMaintenanceMiles = aircraft.getNextMaintenanceMiles();
			System.out.println(String.format("%s\t%s\t%s\t%s\t%d", aircraft.getAircraftName(),
					aircraft.getManufacturer(), nextMaintenanceDate, nextMaintenanceMiles));
		}
	}

	public void updateMiles(String regNumber, double miles)
	{
		for (int i = 0; i < count; i++)
		{
			Aircraft aircraft = aircrafts[i];
			if (aircraft.getRegNumber().equals(regNumber))
			{
				aircraft.setTotalMiles(miles);
				break;
			}
		}
	}

	public void updateMaintenance(String regNumber)
	{
		for (int i = 0; i < count; i++)
		{
			Aircraft aircraft = aircrafts[i];
			if (aircraft.getRegNumber().equals(regNumber))
			{
				aircraft.setLastMaintenanceDate(LocalDate.now());
				aircraft.setLastMaintenanceMiles(aircraft.getTotalMiles());
				break;
			}
		}
	}

	public void displayAircraft(String regNumber)
	{
		for (int i = 0; i < count; i++)
		{
			Aircraft aircraft = aircrafts[i];
			if (aircraft.getRegNumber().equals(regNumber))
			{
				System.out.println(aircraft.toString());
				break;
			}
		}
	}

	public void removeAircraft(String regNumber)
	{
		boolean found = false;
		Aircraft[] newFleet = new Aircraft[aircrafts.length];
		int j = 0;

		for (int i = 0; i < count; i++)
		{
			Aircraft aircraft = aircrafts[i];
			if (!aircraft.getRegNumber().equals(regNumber))
			{
				newFleet[j++] = aircraft;
			} else
			{
				found = true;
			}
		}

		if (found)
		{
			aircrafts = newFleet;
			count--;
		} else
		{
			System.out.println("Aircraft with registration number " + regNumber + " not found.");
		}
	}
}