/*
 * Created on: May 5, 2023
 *
 * ULID: cqtroja
 * Class: IT 168 
 */
package edu.ilstu;

/**
 * <insert class description here>
 *
 * @author Cameron Trojan
 *
 */
import java.util.Scanner;

public class FleetDriver
{
	private Scanner scanner;

	public static void main(String[] args)
	{
		FleetDriver driver = new FleetDriver();
		driver.run();
	}

	public void run()
	{
		Fleet fleet = new Fleet();
		setup(fleet);
	}

	public void setup(Fleet fleet)
	{
		String[] menuItems = { "Add an Aircraft", "Display the Fleet", "Display Aircraft That Need Maintenance",
				"Display Aircraft Next Maintenance Date/Miles", "Record Miles Traveled", "Record Maintenance",
				"Retire Aircraft", "Load from a file", "Write to a file", "Quit" };
		TextMenu menu = new TextMenu(menuItems);
		int choice = 0;
		while (choice != 10)
		{
			choice = menu.getChoice();
			switch (choice)
			{
			case 1:
				Aircraft newAircraft = getAircraftInfo();
				fleet.addAircraft(newAircraft);
				break;
			case 2:
				fleet.displayFleet();
				break;
//                case 3:
//                    fleet.displayAircraftNeedsMaintenance();
//                    break;
//                case 4:
//                    fleet.displayAircraftNextMaintenance();
//                    break;
//                case 5:
//                    fleet.recordMilesTraveled();
//                    break;
//                case 6:
//                    fleet.recordMaintenance();
//                    break;
			case 7:
				fleet.removeAircraft("");
				break;
			case 8:
				fleet.readFile("deltafleet.txt");
				break;
			case 9:
				fleet.writeFile("newdeltafleet.txt");
				break;
			case 10:
				System.out.println("Goodbye!");
				break;
			default:
				System.out.println("Invalid choice, please try again.");
			}
		}
	}

	public Aircraft getAircraftInfo()
	{
		System.out.println("Enter aircraft name: ");
		String aircraftName = scanner.next();
		System.out.println("Enter registration num: ");
		String regNum = scanner.next();
		System.out.println("Enter manufacturer: ");
		String manufacturer = scanner.next();
		System.out.println("Enter max range: ");
		int maxRange = scanner.nextInt();
		System.out.println("Enter crew size: ");
		int crewSize = scanner.nextInt();
		System.out.println("Enter year put in service: ");
		int yearPutInService = scanner.nextInt();
		System.out.println("Enter max weight: ");
		int maxServiceWeight = scanner.nextInt();
		System.out.println("Enter number of passengers: ");
		int numPassangers = scanner.nextInt();
		System.out.println("Enter last maintenance miles: ");
		int lastMaintenanceMiles = scanner.nextInt();

		return getAircraftInfo();

	}
}
