/*
 * Created on: Apr 25, 2023
 *
 * ULID: cqtroja
 * Class: IT 168 
 */
package edu.ilstu;

/**
 * <insert class description here>
 *
 * @author Cameron Trojan
 *
 */
import java.util.Scanner;

public class TextMenu
{
	private String[] menuOptions;

	public TextMenu(String[] options)
	{
		menuOptions = new String[options.length];
		System.arraycopy(options, 0, menuOptions, 0, options.length);
	}

	public void displayMenu()
	{
		for (int i = 0; i < menuOptions.length; i++)
		{
			System.out.println((i + 1) + ". " + menuOptions[i]);
		}
	}

	public int getChoice()
	{
		int choice = -1;
		do
		{
			displayMenu();
			Scanner scanner = new Scanner(System.in);
			System.out.print("Enter your choice: ");
			String input = scanner.nextLine();
			choice = validateChoice(input);
		} while (choice == -1);
		return choice;
	}

	public int validateChoice(String choiceString)
	{
		int choice = -1;
		try
		{
			choice = Integer.parseInt(choiceString);
			if (choice < 1 || choice > menuOptions.length)
			{
				System.out.println("Invalid choice. Please enter a number between 1 and " + menuOptions.length);
				choice = -1;
			}
		} catch (NumberFormatException e)
		{
			System.out.println("Invalid choice. Please enter a number between 1 and " + menuOptions.length);
		}
		return choice;
	}
}
