/*
 * Created on: Apr 24, 2023
 *
 * ULID: cqtroja
 * Class: IT 168 
 */
package edu.ilstu;

/**
 * <insert class description here>
 *
 * @author Cameron Trojan
 *
 */
import java.time.LocalDate;

public class Aircraft implements CharSequence
{
	private String aircraftName;
	private String regNumber;
	private String manufacturer;
	private int maxRange;
	private int crewSize;
	private int yearPutInService;
	private int maxServiceWeight;
	private int numPassengers;
	private LocalDate lastMaintenanceDate;
	private int lastMaintenanceMiles;

	public Aircraft()
	{
		this.aircraftName = "";
		this.regNumber = "";
		this.manufacturer = "";
		this.maxRange = 0;
		this.crewSize = 0;
		this.yearPutInService = 0;
		this.maxServiceWeight = 0;
		this.numPassengers = 0;
		this.lastMaintenanceDate = LocalDate.now();
		this.lastMaintenanceMiles = 0;
	}

	public Aircraft(String aircraftName, String regNumber, String manufacturer, int maxRange, int crewSize,
			int yearPutInService, int maxServiceWeight, int numPassangers, LocalDate lastMaintenanceDate,
			int lastMaintenanceMiles)
	{
		this();
	}

	public boolean needsMaintenance(LocalDate currentDate)
	{
		LocalDate today = LocalDate.now();
		LocalDate threeMonthsAgo = today.minusMonths(3);
		return lastMaintenanceDate.isBefore(threeMonthsAgo) || lastMaintenanceMiles >= 150_000;
	}

	public boolean shouldRetire()
	{
		LocalDate today = LocalDate.now();
		int yearsInService = today.getYear() - yearPutInService;
		return yearsInService > 20 || lastMaintenanceMiles > 2_000_000;
	}

	@Override
	public String toString()
	{
		return "Aircraft{" + "aircraftName='" + aircraftName + '\'' + ", regNumber='" + regNumber + '\''
				+ ", manufacturer='" + manufacturer + '\'' + ", maxRange=" + maxRange + ", crewSize=" + crewSize
				+ ", yearPutInService=" + yearPutInService + ", maxServiceWeight=" + maxServiceWeight
				+ ", numPassengers=" + numPassengers + ", lastMaintenanceDate=" + lastMaintenanceDate
				+ ", lastMaintenanceMiles=" + lastMaintenanceMiles + '}';
	}

	public String getAircraftName()
	{
		return aircraftName;
	}

	public void setAircraftName(String aircraftName)
	{
		this.aircraftName = aircraftName;
	}

	public String getRegNumber()
	{
		return regNumber;
	}

	public void setRegNumber(String regNumber)
	{
		this.regNumber = regNumber;
	}

	public String getManufacturer()
	{
		return manufacturer;
	}

	public void setManufacturer(String manufacturer)
	{
		this.manufacturer = manufacturer;
	}

	public int getMaxRange()
	{
		return maxRange;
	}

	public void setMaxRange(int maxRange)
	{
		this.maxRange = maxRange;
	}

	public int getCrewSize()
	{
		return crewSize;
	}

	public void setCrewSize(int crewSize)
	{
		this.crewSize = crewSize;
	}

	public int getYearPutInService()
	{
		return yearPutInService;
	}

	public void setYearPutInService(int yearPutInService)
	{
		this.yearPutInService = yearPutInService;
	}

	public int getMaxServiceWeight()
	{
		return maxServiceWeight;
	}

	public void setMaxServiceWeight(int maxServiceWeight)
	{
		this.maxServiceWeight = maxServiceWeight;
	}

	public int getNumPassengers()
	{
		return numPassengers;
	}

	public void setNumPassengers(int numPassengers)
	{
		this.numPassengers = numPassengers;
	}

	public LocalDate getLastMaintenanceDate()
	{
		return lastMaintenanceDate;
	}

	public void setLastMaintenanceDate(LocalDate date)
	{
		this.lastMaintenanceDate = date;
	}

	public int getLastMaintenanceMiles()
	{
		return lastMaintenanceMiles;
	}

	public void setLastMaintenanceMiles(int lastMaintenanceMiles)
	{
		this.lastMaintenanceMiles = lastMaintenanceMiles;
	}

	public int getTotalMiles()
	{
		return getLastMaintenanceMiles();

	}

	public LocalDate getNextMaintenanceDate(LocalDate currentDate)
	{
		return getLastMaintenanceDate().plusMonths(3);
	}

	public int getNextMaintenanceMiles()
	{
		return getLastMaintenanceMiles() + 3000;
	}

	public void setTotalMiles(double miles)
	{
		// TODO Auto-generated method stub

	}

	@Override
	public int length()
	{
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public char charAt(int index)
	{
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public CharSequence subSequence(int start, int end)
	{
		// TODO Auto-generated method stub
		return null;
	}

}
