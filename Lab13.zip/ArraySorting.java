package edu.ilstu;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Scanner;

/**
 * Program that works with arrays of integers including sorting and merging
 * sorted arrays
 * 
 * @author Mary Elaine Califf, Cameron and Mikolaj
 *
 */
public class ArraySorting
{
	/**
	 * Method to read the values of an array
	 * 
	 * @param theArray      Array to be read
	 * @param inputFileName Name of input file
	 * @return Number of valid values in the array
	 */
	public static int readArray(int[] theArray, String inputFileName)
	{
		// read the contents of the specified file into theArray and return the number
		// of elements read
		// you may assume that the array will be big enough
		// you must handle relevant exceptions

		int count = 0;
		try
		{
			Scanner scanner = new Scanner(new File(inputFileName));
			while (scanner.hasNextInt())
			{
				theArray[count++] = scanner.nextInt();
			}
			scanner.close();
		} catch (FileNotFoundException e)
		{
			System.out.println("File not found: " + inputFileName);
		} catch (IOException e)
		{
			System.out.println("Error reading file: " + e.getMessage());
		}
		return count;

	}

	/**
	 * Writes elements of theArray to a specefied file
	 * 
	 * @param theArray       Array
	 * @param numValues      Number of values in the array
	 * @param outputFileName Name of the output file
	 */
	public static void writeArray(int[] theArray, int numValues, String outputFileName)
	{
		// write the first numValues elements of theArray to the specified file
		// you must handle relevant exceptions
		try
		{
			PrintWriter writer = new PrintWriter(outputFileName);
			for (int i = 0; i < numValues; i++)
			{
				writer.println(theArray[i]);
			}
			writer.close();
		} catch (FileNotFoundException e)
		{
			System.out.println("File not found: " + outputFileName);
		} catch (IOException e)
		{
			System.out.println("Error writing to file: " + e.getMessage());
		}
	}

	/**
	 * Sorts an array
	 * 
	 * @param theArray  The array
	 * @param numValues Number of values in the the array
	 */
	public static void selectionSort(int[] theArray, int numValues)
	{
		// sort the first numValue elements of theArray using the selection sort
		// algorithm

		for (int i = 0; i < numValues - 1; i++)
		{
			int minIndex = i;
			for (int j = i + 1; j < numValues; j++)
			{
				if (theArray[j] < theArray[minIndex])
				{
					minIndex = j;
				}
			}
			int temp = theArray[minIndex];
			theArray[minIndex] = theArray[i];
			theArray[i] = temp;
		}

	}

	/**
	 * Method to merge array
	 * 
	 * @param arr1      First array
	 * @param size1     Size of the array
	 * @param arr2      Second array
	 * @param size2     Size of second array
	 * @param mergedArr Merged array
	 * @return Number of valid values in both arrays
	 */
	public static int mergeArrays(int[] arr1, int size1, int[] arr2, int size2, int[] mergedArr)
	{
		int i = 0, j = 0, k = 0;

		while (i < size1 && j < size2)
		{
			if (arr1[i] <= arr2[j])
			{
				mergedArr[k] = arr1[i];
				i++;
			} else
			{
				mergedArr[k] = arr2[j];
				j++;
			}
			k++;
		}

		while (i < size1)
		{
			mergedArr[k] = arr1[i];
			i++;
			k++;
		}

		while (j < size2)
		{
			mergedArr[k] = arr2[j];
			j++;
			k++;
		}

		return k;

	}

	public static void main(String[] args)
	{
		// Test just the reading and writing -- check contents of numbersout.txt
		int[] array1 = new int[100];
		int numElems1 = readArray(array1, "numbers.txt");
		writeArray(array1, numElems1, "numbersout.txt");

		// Test the sorting -- check contents of sortedout.txt
		selectionSort(array1, numElems1);
		writeArray(array1, numElems1, "sortedout.txt");

		// Read second array and test merging -- check contents of mergedout.txt
		int[] array2 = new int[100];
		int numElems2 = readArray(array2, "numbers2.txt");
		int[] array3 = new int[200];
		int numElems3 = mergeArrays(array1, numElems1, array2, numElems2, array3);
		writeArray(array3, numElems3, "mergedout.txt");

	}

}