/*
 * Created on: Apr 6, 2023
 *
 * ULID: cqtroja
 * Class: IT 168 
 */
package edu.ilstu;

/**
 * Constructor class for usage in MailBox. This class has constructor Email that
 * takes date, urgency, and subject. This class also defines getters & setters.
 *
 * @author Cameron Trojan
 *
 */
public class Email
{
	private String subject;
	private boolean urgent;
	private Date date;

	/**
	 * Constructor for Email, taking parameters date, urgent, and subject
	 * 
	 * @param date    Date of email
	 * @param urgent  True if ugrent, false if not
	 * @param subject Subject of email
	 */
	public Email(Date date, boolean urgent, String subject)
	{
		this.date = date;
		this.urgent = urgent;
		this.subject = subject;
	}

	/**
	 * Getter for email subject
	 * 
	 * @return Returns subject of email
	 */
	public String getSubject()
	{
		return subject;
	}

	/**
	 * Setter for email subject
	 * 
	 * @param subject Subject of email
	 */
	public void setSubject(String subject)
	{
		this.subject = subject;
	}

	/**
	 * Getter for email urgency
	 * 
	 * @return Returns true if email is urgent, otherwise returns false
	 */
	public boolean isUrgent()
	{
		return urgent;
	}

	/**
	 * Setter for email urgency
	 * 
	 * @param urgent Urgency of email
	 */
	public void setUrgent(boolean urgent)
	{
		this.urgent = urgent;
	}

	/**
	 * Getter for email date
	 * 
	 * @return Returns email date
	 */
	public Date getDate()
	{
		return date;
	}

	/**
	 * Setter for email date
	 * 
	 * @param date Date of email
	 */
	public void setDate(Date date)
	{
		this.date = date;
	}

	@Override
	public String toString()
	{
		return "Date: " + date.toString() + "\nSubject: " + subject + "\nUrgent: " + urgent;
	}

}
