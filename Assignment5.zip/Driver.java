/*
 * Created on: Apr 10, 2023
 *
 * ULID: cqtroja
 * Class: IT 168 
 */
package edu.ilstu;

import java.util.Scanner;

/**
 * <insert class description here>
 *
 * @author Cameron Trojan
 *
 */
public class Driver
{

	/**
	 * @param args
	 */
	public static void main(String[] args)
	{
		Scanner sc = new Scanner(System.in);

		MailBox[] mailboxes = new MailBox[5];
		MailBox mailbox1 = new MailBox("gmail");
		MailBox mailbox2 = new MailBox("outlook");
		MailBox mailbox3 = new MailBox("icloud");

		Email email1 = new Email(new Date(2022, 11, 5), false, "Exam2 guidelines");
		email1.setDate(new Date(2022, 11, 5));
		email1.setSubject("Exam2 guidelines");

		Email email2 = new Email(new Date(2021, 3, 5), true, "Quiz3 in Ch7");

		Email email3 = new Email(new Date(2020, 11, 3), false, "");
		email3.setDate(new Date(2020, 11, 3));
		email3.setSubject("Late submission policy");

		mailbox1.addEmail(email1);
		mailbox2.addEmail(email2);
		mailbox3.addEmail(email3);

		System.out.println(mailbox1.getClient());
		System.out.println(mailbox2.getClient());
		System.out.println(mailbox3.getClient());

		displayMenu();
		int choice = sc.nextInt();

		while (choice != 5)
		{
			switch (choice)
			{
			case 1:
				// Option 1: List Emails in a mailbox
				System.out.print("Enter Client: ");
				String client1 = sc.next();
				mailbox1 = findMailbox(mailboxes, client1);
				if (mailbox1 != null)
				{
					System.out.println(mailbox1.toString());
				} else
				{
					System.out.println("Mailbox not found.");
				}
				break;
			case 2:
				// Option 2: Add an email to a mailbox
				System.out.print("For which client? ");
				String client2 = sc.next();
				addEmailToMailbox(client2, mailboxes);
				break;
			case 3:
				// Option 3: Search for an email in a mailbox by year
				System.out.print("For which client? ");
				String client3 = sc.next();
				System.out.print("For which year? ");
				int year = sc.nextInt();
				mailbox3 = findMailbox(mailboxes, client3);
				if (mailbox3 != null)
				{
					mailbox3.findEmail(year);
				} else
				{
					System.out.println("Mailbox not found.");
				}
				break;
			case 4:
				// Option 4: Sort emails in a mailbox by year
				System.out.print("For which client? ");
				String client4 = sc.next();
				MailBox mailbox4 = findMailbox(mailboxes, client4);
				if (mailbox4 != null)
				{
					mailbox4.sortEmails();
					System.out.println("Emails sorted by year!");
				} else
				{
					System.out.println("Mailbox not found.");
				}
				break;

			case 5:
				// Option 5: Quit
				System.out.println("Goodbye!");
				break;

			default:
				System.out.println("Invalid choice. Please try again.");
				break;
			}

		}

	}

	static void displayMenu()
	{
		System.out.println("Hello! What would you like to do? ");
		System.out.println("1- List Emails in a mailbox");
		System.out.println("2- Add an email to a mailbox");
		System.out.println("3- Search for an email in a mailbox by year");
		System.out.println("4- Sort emails in a mailbox by year");
		System.out.println("5- Quit");
	}

	public static MailBox findMailbox(MailBox[] mailboxes, String client)
	{
		for (MailBox mailbox : mailboxes)
		{
			if (mailbox != null && mailbox.getClient().equalsIgnoreCase(client))
			{
				return mailbox;
			}
		}
		return null;
	}

	public static void addEmailToMailbox(String client, MailBox[] mailboxes)
	{
		MailBox mailbox = findMailbox(mailboxes, client);
		if (mailbox != null)
		{
			Scanner scanner = new Scanner(System.in);
			System.out.println("Enter email information on one line as follows:");
			System.out.println("<urgent>,<m>,<d>,<y>,<Msg>");
			String input = scanner.nextLine();
			String[] emailData = input.split(",");
			if (emailData.length == 5)
			{
				boolean urgent = Boolean.parseBoolean(emailData[0]);
				int month = Integer.parseInt(emailData[1]);
				int day = Integer.parseInt(emailData[2]);
				int year = Integer.parseInt(emailData[3]);
				String subject = emailData[4];
				Email email = new Email(new Date(year, month, day), urgent, subject);
				if (mailbox.addEmail(email))
				{
					System.out.println("Email added successfully.");
				} else
				{
					System.out.println("You have reached maximum capacity. Upgrade your account.");
				}
			} else
			{
				System.out.println("Invalid input.");
			}
		} else
		{
			System.out.println("Mailbox not found.");
		}
	}
}
