/*
 * Created on: Apr 6, 2023
 *
 * ULID: cqtroja
 * Class: IT 168 
 */
package edu.ilstu;

/**
 * Constructor class for Email & MailBox. This class has a constructor called
 * Date, which takes parameters year, month, and day. This class also defines
 * getters & setters.
 *
 * @author Cameron Trojan
 *
 */
public class Date
{
	private int year;
	private int month;
	private int day;

	/**
	 * Constructor for the date taking parameters year, month, and day
	 * 
	 * @param year  Date year
	 * @param month Date month
	 * @param day   Date day
	 */
	public Date(int year, int month, int day)
	{
		this.year = year;
		this.month = month;
		this.day = day;
	}

	/**
	 * Getter for year
	 * 
	 * @return Returns year
	 */
	public int getYear()
	{
		return year;
	}

	/**
	 * Getter for month
	 * 
	 * @return Returns month
	 */
	public int getMonth()
	{
		return month;
	}

	/**
	 * Getter for day
	 * 
	 * @return Returns day
	 */
	public int getDay()
	{
		return day;
	}

	@Override
	public String toString()
	{
		return "Date: " + month + "/" + day + "/" + year;
	}

}
