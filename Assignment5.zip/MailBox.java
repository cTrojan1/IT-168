/*
 * Created on: Apr 6, 2023
 *
 * ULID: cqtroja
 * Class: IT 168 
 */
package edu.ilstu;

import java.util.Arrays;
import java.util.Comparator;

/**
 * <insert class description here>
 *
 * @author Cameron Trojan
 *
 */
public class MailBox
{
	static String client;
	int actualSize = 0;
	Email[] emails;

	public MailBox()
	{
		MailBox.client = "";
		this.emails = new Email[10];
		this.actualSize = 0;
	}

	public MailBox(String client)
	{
		MailBox.client = client;
		this.emails = new Email[10];
		this.actualSize = 0;
	}

	public String getClient()
	{
		return client;
	}

	public int getActualSize()
	{
		return actualSize;
	}

	public Email getEmail(int index)
	{
		if (index >= 0 && index < actualSize)
		{
			return emails[index];
		} else
		{
			System.out.println("Invalid index");
			return null;
		}
	}

	public boolean addEmail(Email email)
	{
		if (actualSize < emails.length)
		{
			emails[actualSize++] = email;
			return true; // Return true indicating email was added successfully
		} else
		{
			System.out.println("Mailbox is full. Cannot add more emails.");
			return false; // Return false indicating email was not added due to mailbox being full
		}
	}

	public void sortEmails()
	{
		// Sort the emails array using a custom comparator
		Arrays.sort(emails, 0, actualSize, new Comparator<Email>()
		{
			@Override
			public int compare(Email email1, Email email2)
			{
				// Compare the dates in reverse order for descending sorting
				Date date1 = email1.getDate();
				Date date2 = email2.getDate();
				if (date1.getYear() != date2.getYear())
				{
					return Integer.compare(date2.getYear(), date1.getYear());
				} else if (date1.getMonth() != date2.getMonth())
				{
					return Integer.compare(date2.getMonth(), date1.getMonth());
				} else
				{
					return Integer.compare(date2.getDay(), date1.getDay());
				}
			}
		});

	}

	public Email findEmail(int year)
	{
		for (int i = 0; i < actualSize; i++)
		{
			if (emails[i].getDate().getYear() == year)
			{
				return emails[i];
			}
		}
		System.out.println("Email not found for the given year.");
		return null;
	}

	public int countUrgent()
	{
		int count = 0;
		for (int i = 0; i < actualSize; i++)
		{
			if (emails[i].isUrgent())
			{
				count++;
			}
		}
		return count;
	}

	// toString method
	public String toString()
	{
		StringBuilder sb = new StringBuilder();
		sb.append("Mailbox for client: ").append(client).append("\n");
		for (int i = 0; i < actualSize; i++)
		{
			sb.append("Email ").append(i + 1).append(":\n").append(emails[i].toString()).append("\n");
		}
		return sb.toString();
	}

}
