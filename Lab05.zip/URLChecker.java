/*
 * Created on: Feb 15, 2023
 *
 * ULID: cqtroja
 * Class: IT 168 
 */
package edu.ilstu;

/**
 * Takes a URL as input and tells the user what the web address is
 *
 * @author Cameron Trojan & Daniel Uraimov
 *
 */
import java.util.Scanner;

public class URLChecker
{
	public static void main(String[] args)
	{
		Scanner scan = new Scanner(System.in);
		System.out.print("Enter a web address (for instance, www.yahoo.com): ");
		String web = scan.nextLine();
		if (web.contains("gov"))
		{
			System.out.println("It is a government web address.");
		}

		else if (web.contains("edu"))
		{
			System.out.println("It is a university web address.");
		}

		else if (web.contains("com"))
		{
			System.out.println("It is a business web address.");
		}

		else if (web.contains("org"))
		{
			System.out.println("It is a non-profit organization’s web address.");
		}

		else
		{
			System.out.println("It is a web address for another entity.");
		}
	}
}
