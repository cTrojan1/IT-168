/*
 * Created on: Feb 15, 2023
 *
 * ULID: cqtroja
 * Class: IT 168 
 */
package edu.ilstu;

/**
 * Generates a random number and decides if it is even or odd and if it less than or 
 * greater than 100
 *
 * @author Cameron Trojan and Daniel Uraimov
 *
 */

import java.util.Random;

public class RandomPlay
{
	public static void main(String[] args)
	{

		final int LARGE = 100;
		final int NUM = 200;

		Random r = new Random();
		int num1 = r.nextInt(1, 200 + 1);

		System.out.println(num1);

		if (num1 > LARGE && num1 % 2 == 0)
		{
			System.out.println("The number is greater than 100 and even, it is" + num1);
		}

		else if (num1 > LARGE && num1 % 2 != 0)
		{
			System.out.println("The number is greater than 100 and odd.");
		}

		else if (num1 < LARGE && num1 % 2 == 0)
		{
			System.out.println("The number is less than 100 and even.");
		}

		else if (num1 > LARGE && num1 % 2 != 0)
		{
			System.out.println("The number is less than 100 and odd.");
		}

		int num2 = r.nextInt(1, 200 + 1);

		if (num1 > num2)
		{
			System.out.println(num2 + " is less than the first number" + num1);

		}

		else
		{
			System.out.println(num2 + " is greater than the first number" + num1);
		}

	}

}
