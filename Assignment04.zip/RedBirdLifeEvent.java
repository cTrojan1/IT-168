/*
 * Created on: Apr 1, 2023
 *
 * ULID: cqtroja
 * Class: IT 168 
 */
package edu.ilstu;

import java.util.Random;

/**
 * 
 * RedBirdLifeEvent represents events at Illinois State University. Each event
 * is identified by a unique 7 digit bar code. It also keeps track of the
 * location, capacity, and number of seats taken.
 *
 * @author Cameron Trojan
 *
 */
public class RedBirdLifeEvent
{
	private static int numEvents = 0; // class variable to keep track of the number of event objects created
	private String barCode; // a 7 digit alpha numeric unique bar code for each event
	private String location; // the location of the event, which starts with the name of the building
								// followed by the room number (e.g. Center for Visual Arts 151)
	private String eventName; // event name
	private String eventType; // event type, which can be one of the following: Workshop, Seminar,
								// Career fair
	private int quantity; // represents how many seats are requested
	private int capacity; // the event capacity (max number of spots allowed for this event)
	private int seatsTaken; // the number of seats already taken

	public RedBirdLifeEvent()
	{
		numEvents++;
	}

	/**
	 * Constructor for event that takes eventName and eventType
	 * 
	 * @param eventName
	 * @param eventType
	 */
	public RedBirdLifeEvent(String eventName, String eventType)
	{
		this();
		this.eventName = eventName;
		this.eventType = eventType;
		this.seatsTaken = 0;
		calcMaximumSeats(eventType);
		generateBarCode();
	}

	/**
	 * Constructor for event that takes eventName, eventType, and capacity
	 * 
	 * @param eventName - Name of the event
	 * @param eventType - Event type
	 * @param capacity  - Capacity of event
	 */
	public RedBirdLifeEvent(String eventName, String eventType, int capacity)
	{
		// this(eventName, eventType);
		this.eventName = eventName;
		this.eventType = eventType;
		this.capacity = capacity;
	}

	/**
	 * Method to set maximum seats
	 * 
	 * @param eventType - Event type
	 */
	private void calcMaximumSeats(String eventType)
	{
		switch (eventType)
		{
		case "Workshop":
			location = "Jullian Hall 28";
			capacity = 30;
			break;
		case "Seminar":
			location = "Visual Arts 151";
			capacity = 100;
			break;
		case "Workshop2":
			location = "Jullian Hall 28";
			capacity = 10;
			break;
		case "Career fair":
			location = "Performing Arts Lobby";
			capacity = 100000000;
			break;
		}
	}

	void generateBarCode()
	{
		Random rand = new Random();
		int num = rand.nextInt(9000) + 1000;
		String barcode = eventName.charAt(0) + "" + location.charAt(0) + "" + num;
		barCode = barcode.toUpperCase();
	}

	/**
	 * Getter for events barcode
	 * 
	 * @return Barcode for event
	 */
	public String getBarCode()
	{
		return barCode;
	}

	/**
	 * Getter for event location
	 * 
	 * @return Location of event
	 */
	public String getLocation()
	{
		return location;
	}

	/**
	 * Setter for event location
	 * 
	 * @param location - Location of event
	 */
	public void setLocation(String location)
	{
		this.location = location;
	}

	/**
	 * Getter for event name
	 * 
	 * @return Name of event
	 */
	public String getEventName()
	{
		return eventName;
	}

	/**
	 * Setter for event name
	 * 
	 * @param eventName - Name of event
	 */
	public void setEventName(String eventName)
	{
		this.eventName = eventName;
	}

	/**
	 * Getter for eventType
	 * 
	 * @return Type of event
	 */
	public String getEventType()
	{
		return eventType;
	}

	/**
	 * Setter for eventType
	 * 
	 * @param eventType - Type of event
	 */
	public void setEventType(String eventType)
	{
		this.eventType = eventType;
	}

	/**
	 * Getter for quantity
	 * 
	 * @return Quantity
	 */
	public int getQuantity()
	{
		return quantity;
	}

	/**
	 * Setter for quantity to register
	 * 
	 * @param quantity - Number of people to register
	 */
	public void setQuantity(int quantity)
	{
		this.quantity = quantity;
	}

	/**
	 * Getter for event capacity
	 * 
	 * @return Capacity of event
	 */
	public int getCapacity()
	{
		return capacity;
	}

	/**
	 * Setter for event capacity
	 * 
	 * @param capacity - Max capacity for event
	 */
	public void setCapacity(int capacity)
	{
		this.capacity = capacity;
	}

	/**
	 * Getter for number of seats take in an event
	 * 
	 * @return Number of seats taken
	 */
	public int getSeatsTaken()
	{
		return seatsTaken;
	}

	/**
	 * Setter for number of seats taken in an event
	 * 
	 * @param seatsTaken - Number of seats taken
	 */
	public void setSeatsTaken(int seatsTaken)
	{
		this.seatsTaken = seatsTaken;
	}

	/**
	 * Getter for available seats in an event
	 * 
	 * @return Number of available seats
	 */
	public int getAvailableSeats()
	{
		return capacity - seatsTaken;
	}

	/**
	 * Registration method for single person
	 * 
	 * @return registers one person for an event
	 */
	public boolean register()
	{
		return register(1);
	}

	/**
	 * Registration method for multiple people
	 * 
	 * @param quantity - Number of people trying to register
	 * @return true if there are seats available when trying to register, false if
	 *         there are not
	 */
	public boolean register(int quantity)
	{
		if (eventType.equals("Career fair"))
		{
			seatsTaken += quantity;
			return true;
		} else if (getAvailableSeats() >= quantity)
		{
			seatsTaken += quantity;
			return true;
		} else
		{
			return false;
		}
	}

	/**
	 * Cancels registration if there are not enough seats
	 * 
	 * @param quantity - Number of people trying to register
	 */
	public void cancelRegistration(int quantity)
	{
		seatsTaken -= quantity;
	}

	/**
	 * Method to determine if an event is full
	 * 
	 * @return True if event is full, false if there are seats available
	 */
	public boolean isFull()
	{
		return seatsTaken == capacity;
	}
}