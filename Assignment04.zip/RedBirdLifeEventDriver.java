/*
 * Created on: Apr 1, 2023
 *
 * ULID: cqtroja
 * Class: IT 168 
 */
package edu.ilstu;

import java.util.Scanner;

/**
 * Driver class for RedBirdLifeEvent
 *
 * @author Cameron Trojan
 *
 */
public class RedBirdLifeEventDriver
{

	/**
	 * @param args
	 */
	public static void main(String[] args)
	{
		Scanner sc = new Scanner(System.in);

		String choice = " ";

		RedBirdLifeEvent event1 = new RedBirdLifeEvent("Success in IT168", "Workshop");
		event1.generateBarCode();
		RedBirdLifeEvent event2 = new RedBirdLifeEvent("Test Prep Seminar", "Seminar");
		event2.generateBarCode();
		RedBirdLifeEvent event3 = new RedBirdLifeEvent("Working in Teams", "Workshop2");
		event3.generateBarCode();
		RedBirdLifeEvent event4 = new RedBirdLifeEvent("SIT Career Fair", "Career fair");
		event4.generateBarCode();

		while (!choice.equals("Q"))
		{
			displayMenu();
			choice = sc.next().toUpperCase();

			switch (choice)
			{
			case "L":
				System.out.println("Listing all events...");
				System.out.println("---------------------");
				System.out.println(event1.getBarCode() + "\t " + event1.getEventName() + "\t " + event1.getLocation()
						+ "\t " + event1.getAvailableSeats());
				System.out.println(event2.getBarCode() + "\t " + event2.getEventName() + "\t " + event2.getLocation()
						+ "\t " + event2.getAvailableSeats());
				System.out.println(event3.getBarCode() + "\t " + event3.getEventName() + "\t " + event3.getLocation()
						+ "\t " + event3.getAvailableSeats());
				System.out.println(event4.getBarCode() + "\t " + event4.getEventName() + "\t " + event4.getLocation()
						+ "\t Unlimted");
				System.out.println("---------------------");

				break;

			case "IR":
				System.out.println("What event do you want to register for? (Enter barcode): ");
				String barcode = sc.next();

				if (barcode.equals(event1.getBarCode()) && event1.getAvailableSeats() > 0)
				{
					event1.register(1);
					System.out.println("Registration successful.");
				} else if (event1.getAvailableSeats() == 0)
				{
					System.out.println("Sorry, this event is full.");
				} else if (barcode.equals(event2.getBarCode()) && event2.getAvailableSeats() > 0)
				{
					event2.register(1);
					System.out.println("Registration successful.");
				} else if (event2.getAvailableSeats() == 0)
				{
					System.out.println("Sorry, this event is full.");
				} else if (barcode.equals(event3.getBarCode()))
				{
					event3.register(1);
					System.out.println("Registration successful.");
				} else if (event3.getAvailableSeats() == 0)
				{
					System.out.println("Sorry, this event is full.");
				} else if (barcode.equals(event4.getBarCode()))
				{
					event4.register(1);
					System.out.println("Registration successful.");
				} else
				{
					System.out.println("Invalid input");
				}
				break;

			case "GR":
				System.out.println("Enter the barcode of the event you want to register for:");
				String groupBarcode = sc.next();

				if (groupBarcode.equals(event1.getBarCode()))
				{
					System.out.println("Enter the number of seats you need:");
					int groupSize = sc.nextInt();
					if (event1.getAvailableSeats() >= groupSize)
					{
						event1.register(groupSize);
						System.out.println("Registration successful.");
					} else
					{
						System.out.println("Sorry, there are not enough seats available for your group.");
					}
				}

				else if (groupBarcode.equals(event2.getBarCode()))
				{
					System.out.println("Enter the number of seats you need:");
					int groupSize = sc.nextInt();
					if (event2.getAvailableSeats() >= groupSize)
					{
						event2.register(groupSize);
						System.out.println("Registration successful.");
					} else
					{
						System.out.println("Sorry, there are not enough seats available for your group.");
					}
				}

				else if (groupBarcode.equals(event3.getBarCode()))
				{
					System.out.println("Enter the number of seats you need:");
					int groupSize = sc.nextInt();
					if (event3.getAvailableSeats() >= groupSize)
					{
						event3.register(groupSize);
						System.out.println("Registration successful.");
					} else
					{
						System.out.println("Sorry, there are not enough seats available for your group.");
					}
				}

				else if (groupBarcode.equals(event4.getBarCode()))
				{
					System.out.println("Enter the number of seats you need:");
					int groupSize = sc.nextInt();
					if (event4.getAvailableSeats() >= groupSize)
					{
						event4.register(groupSize);
						System.out.println("Registration successful.");
					} else
					{
						System.out.println("Sorry, there are not enough seats available for your group.");
					}
				}

				else
				{
					System.out.println("Invalid input.");
				}
				break;

			case "Q":
				System.out.println("Goodbye!");
			}

		}
	}

	public static void displayMenu()
	{
		System.out.println("Please choose one of the following:");
		System.out.println("L - List all available events");
		System.out.println("IR - Individual registration");
		System.out.println("GR - Group registration");
		System.out.println("Q - Quit");
		System.out.println("\nEnter your choice: ");
	}
}