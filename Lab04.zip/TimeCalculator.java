/*
 * Created on: Feb 7, 2023
 *
 * ULID: cqtroja
 * Class: IT 168 
 */
package edu.ilstu;

/**
 * This program asks a user for an input of seconds. It then takes the number of seconds
 * and converts it into hours, minutes, and seconds.
 *
 * @author Cameron Trojan, Dylan Voss(dxvoss)
 *
 */
import java.util.Scanner;

public class TimeCalculator
{
	public static void main(String[] args)
	{
		Scanner sc = new Scanner(System.in);

		System.out.println("Enter a number of seconds: ");
		int sec = sc.nextInt();

		int s = sec % 60;
		int h = sec / 60;
		int m = h % 60;
		h = h / 60;

		System.out.println("Hours: " + h);
		System.out.println("Minutes: " + m);
		System.out.println("Seconds: " + s);

	}

}