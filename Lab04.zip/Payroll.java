/*
 * Created on: Feb 8, 2023
 *
 * ULID: cqtroja
 * Class: IT 168 
 */
package edu.ilstu;

import java.text.DecimalFormat;
import java.util.Scanner;

/**
 * Uses classes and objects to create an employee database and tracks pay rate,
 * name, and raises
 *
 * @author Cameron Trojan(cqtroja), Dylan Voss(dxvoss)
 *
 */
public class Payroll
{
	public static void main(String[] args)
	{
		Scanner sc = new Scanner(System.in);
		DecimalFormat df = new DecimalFormat("$###,###.00");

		Employee e1 = new Employee("John", "Smith", 15);

		// initializes user created employee
		System.out.println("Enter a first name: ");
		String fName = sc.nextLine();

		System.out.println("Enter a last name: ");
		String lName = sc.nextLine();

		System.out.println("Enter a payrate: ");
		double rate = sc.nextDouble();

		Employee e2 = new Employee(fName, lName, rate);

		e1.print();
		e2.print();

		// calculates and returns the weekly pay
		System.out.println(e1.getName() + " earned: " + df.format(e1.calculatePay(42)));
		System.out.println(e2.getName() + " earned: " + df.format(e2.calculatePay(40)));

		// Takes pay rate and gives a percentage raise
		System.out.println("Enter percentage raise for employee 1: ");
		double r1 = sc.nextDouble();
		System.out.println("Enter percentage raise for employee 2: ");
		double r2 = sc.nextDouble();

		e1.giveRaise(r1);
		e2.giveRaise(r2);

		// prints payroll
		// System.out.print("");
		e1.printPayrollLine(42);
		e2.printPayrollLine(40);

		// prints employee data
		e1.print();
		e2.print();

	}

}
